from A3CandWorkers import A3C
import gym

if __name__ == "__main__":
    envs = [gym.make(env_name) for env_name in ['Hopper-v4', 'Ant-v4', 'Humanoid-v4', 'HalfCheetah-v4']]
    state_dim = envs[0].observation_space.shape[0]
    action_dim = envs[0].action_space.shape[0]

    a3c = A3C(state_dim, action_dim)
    a3c.train(envs, num_processes=4, num_steps=20)

import torch
import torch.nn as nn
import torch.optim as optim
import numpy as np

# 定义Actor-Critic网络
class ActorCritic(nn.Module):
    def __init__(self, state_dim, action_dim):
        super(ActorCritic, self).__init__()
        self.fc1 = nn.Linear(state_dim, 256)
        self.fc2 = nn.Linear(256, 128)

        # Actor head
        self.action_mean = nn.Linear(128, action_dim)
        self.action_log_std = nn.Parameter(torch.zeros(1, action_dim))

        # Critic head
        self.value = nn.Linear(128, 1)

    def forward(self, x):
        x = torch.relu(self.fc1(x))
        x = torch.relu(self.fc2(x))
        action_mean = self.action_mean(x)
        action_log_std = self.action_log_std.expand_as(action_mean)
        value = self.value(x)
        return action_mean, action_log_std, value

    def get_action(self, state):
        action_mean, action_log_std, _ = self.forward(state)
        action_std = action_log_std.exp()
        normal = torch.distributions.Normal(action_mean, action_std)
        action = normal.sample()
        return action, normal.log_prob(action), normal.entropy()

    def evaluate_action(self, state, action):
        action_mean, action_log_std, value = self.forward(state)
        action_std = action_log_std.exp()
        normal = torch.distributions.Normal(action_mean, action_std)
        action_log_probs = normal.log_prob(action)
        dist_entropy = normal.entropy()
        return action_log_probs, torch.sum(action_log_probs, dim=1, keepdim=True), value, dist_entropy
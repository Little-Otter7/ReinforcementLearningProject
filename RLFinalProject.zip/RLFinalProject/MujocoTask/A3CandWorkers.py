import torch
import torch.multiprocessing as mp
from ACModel import ActorCritic
class A3C:
    def __init__(self, state_dim, action_dim, lr=1e-4, gamma=0.99, tau=1.0):
        self.global_model = ActorCritic(state_dim, action_dim)
        self.global_model.share_memory()  # Share the model's parameters across processes
        self.optimizer = optim.Adam(self.global_model.parameters(), lr=lr)
        self.gamma = gamma
        self.tau = tau

    def train(self, envs, num_processes, num_steps):
        processes = []
        for rank in range(num_processes):
            p = mp.Process(target=self.worker, args=(rank, envs, num_steps))
            p.start()
            processes.append(p)
        for p in processes:
            p.join()

    def worker(self, rank, envs, num_steps):
        env = envs[rank]
        local_model = ActorCritic(env.observation_space.shape[0], env.action_space.shape[0])
        local_model.load_state_dict(self.global_model.state_dict())
        optimizer = optim.Adam(local_model.parameters(), lr=1e-4)

        state = env.reset()
        state = torch.tensor(state, dtype=torch.float32)
        done = True
        episode_reward = 0
        while True:
            values, log_probs, rewards, entropies = [], [], [], []
            for step in range(num_steps):
                action, log_prob, entropy = local_model.get_action(state)
                next_state, reward, done, _ = env.step(action.numpy())
                episode_reward += reward

                values.append(local_model.forward(state)[2])
                log_probs.append(log_prob)
                rewards.append(reward)
                entropies.append(entropy)

                state = torch.tensor(next_state, dtype=torch.float32)
                if done:
                    state = env.reset()
                    state = torch.tensor(state, dtype=torch.float32)
                    break

            R = torch.zeros(1, 1)
            if not done:
                R = local_model.forward(state)[2]

            values.append(R)
            policy_loss, value_loss, R = 0, 0, R
            for i in reversed(range(len(rewards))):
                R = self.gamma * R + rewards[i]
                advantage = R - values[i]
                value_loss += 0.5 * advantage.pow(2)
                policy_loss -= log_probs[i] * advantage.detach() - 0.01 * entropies[i]

            optimizer.zero_grad()
            loss = policy_loss + 0.5 * value_loss
            loss.backward()
            torch.nn.utils.clip_grad_norm_(local_model.parameters(), 40)
            optimizer.step()

            # Update global model
            for global_param, local_param in zip(self.global_model.parameters(), local_model.parameters()):
                global_param._grad = local_param.grad
            self.optimizer.step()

            local_model.load_state_dict(self.global_model.state_dict())
            if rank == 0 and done:
                print("Episode Reward:", episode_reward)
                episode_reward = 0
